using system.Collections.Generic;
using microsoft.AspNetCore.Mvc;
using _2019VO650.Models;

namespace _2019VO650.Controllers
{
    [ApiController]
    
public class marcaController : ControllerBase
    {   
        private readonly equiposContext_context
        public marcaController(equiposContext contexto)
        {
            this._context=micontexto;
        }
        [HttpGet]
        [Route("api/equipos")]
        public IactionResult Get() {
            List<Models.marca> marcaList = _context.equipos.ToList<equipos>();
            if(marcaList.Count>0){
            return ok(marcaList);
            }
            return NotFound();
        }
    }
}