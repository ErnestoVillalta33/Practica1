using system.Collections.Generic;
using microsoft.AspNetCore.Mvc;
using _2019VO650.Models;

namespace _2019VO650.Controllers
{
    [ApiController]
    
public class tipo_equipoController : ControllerBase
    {   
        private readonly equiposContext_context
        public tipo_equipoController(equiposContext contexto)
        {
            this._context=micontexto;
        }
        [HttpGet]
        [Route("api/equipos")]
        public IactionResult Get() {
            List<Models.tipo_equipo> estados_equipoList = _context.equipos.ToList<tipo_equipo>();
            if(tipo_equipoList.Count>0){
            return ok(tipo_equipoList);
            }
            return NotFound();
        }
    }
}