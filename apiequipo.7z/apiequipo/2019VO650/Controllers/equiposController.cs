using system.Collections.Generic;
using microsoft.AspNetCore.Mvc;
using _2019VO650.Models;

namespace _2019VO650.Controllers
{
    [ApiController]
    
public class equiposController : ControllerBase
    {   
        private readonly equiposContext_context
        public equiposController(equiposContext contexto)
        {
            this._context=micontexto;
        }
        [HttpGet]
        [Route("api/equipos")]
        public IactionResult Get() {
            List<Models.equipos> equiposList = _context.equipos.ToList<equipos>();
            if(equiposList.Count>0){
            return ok(equiposList);
            }
            return NotFound();
        }
    }
}