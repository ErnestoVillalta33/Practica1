using Microsoft.EntityFrameworkCore;
using _2019VO650.Models;
namespace equiposApi
{
    public class equiposContext : DbContext
    {
    public equiposContext(DbContextOption<equiposContext> options)   : base(options)
    {
            }

    public DbSet<equipos>equipos {get;set;}
    public DbSet<estados_equipo>estados_equipo {get;set;}
    public DbSet<equipos>equipos {get;set;}
    public DbSet<estados_equipo>estados_equipo {get;set;}
    public DbSet<marca>marca {get;set;}
    public DbSet<tipo_equipo>tipo_equipo {get;set;}
    }
}