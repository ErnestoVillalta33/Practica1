using Microsoft.EntityFrameworkCore;
using _2019VO650.Models;
namespace equiposApi
{
    public class tipo_equipoContext : DbContext
    {
    public tipo_equipoContext(DbContextOption<tipo_equipoContext> options)   : base(options)
    {
            }


    public DbSet<equipos>tipo_equipos{get;set;}

    }
}