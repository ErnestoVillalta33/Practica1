using Microsoft.EntityFrameworkCore;
using _2019VO650.Models;
namespace equiposApi
{
    public class equiposContext : DbContext
    {
    public equiposContext(DbContextOption<equiposContext> options)   : base(options)
    {
            }


    public DbSet<equipos>equipos {get;set;}

    }
}