using system.Collections.Generic;
using microsoft.AspNetCore.Mvc;
using _2019VO650.Models;

namespace _2019VO650.Controllers
{
    [ApiController]
    
public class estados_equipoController : ControllerBase
    {   
        private readonly estados_equipoContext_context
        public estados_equipoController(estados_equipoContext contexto)
        {
            this._context=micontexto;
        }
        [HttpGet]
        [Route("api/equipos")]
        public IactionResult Get() {
            List<Models.estados_equipo> estados_equipoList = _context.equipos.ToList<estados_equipo>();
            if(estados_equipoList.Count>0){
            return ok(estados_equipoList);
            }
            return NotFound();
        }
    }
}