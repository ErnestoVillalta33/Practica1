using Microsoft.EntityFrameworkCore;
using _2019VO650.Models;
namespace equiposApi
{
    public class estados_equipoContext : DbContext
    {
    public estados_equipoContext(DbContextOption<estados_equipoContext> options)   : base(options)
    {
            }


    public DbSet<equipos>estados_equipo{get;set;}

    }
}