using Microsoft.EntityFrameworkCore;
using _2019VO650.Models;
namespace equiposApi
{
    public class marcaContext : DbContext
    {
    public marcaContext(DbContextOption<marcaContext> options)   : base(options)
    {
            }


    public DbSet<equipos>marca {get;set;}

    }
}